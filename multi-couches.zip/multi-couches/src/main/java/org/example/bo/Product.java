package org.example.bo;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;

import jakarta.persistence.*;
import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFetchProfileType;

import java.util.Set;

@Entity

public class Product {
    @Id
    private Long id;

    private String code;
    private String label;
    private ProdType type;

    private double price;
    public Product() {}

    public Product(Long id, String code, String label, ProdType type, double price) {
        this.id = id;
        this.code = code;
        this.label = label;
        this.type = type;
        this.price = price;
    }


    @ManyToMany(mappedBy = "products")
    private Set<PetStore> petStores;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public ProdType getType() {
        return type;
    }

    public void setType(ProdType type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Set<PetStore> getPetStores() {
        return petStores;
    }

    public void setPetStores(Set<PetStore> petStores) {
        this.petStores = petStores;
    }
}
