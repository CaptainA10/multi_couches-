package org.example.bo;

public enum FishLiEnv {
    FRESH_WATER, SEA_WATER
}
