package org.example.bo;

import jakarta.persistence.Entity;

import java.util.Date;

@Entity
public class Cat extends Animal {
    private String chipIp;

    // Constructeur vide requis par JPA
    public Cat() {}

    // Constructeur avec tous les paramètres utilisés dans ton main
    public Cat(Long id, Date birth, String couleur, PetStore petStore, String chipId) {
        super(id, birth, couleur, petStore); // Appelle le constructeur de Animal
        this.chipIp = chipId;
    }
    public String getChipIp() {
        return chipIp;
    }

    public void setChipIp(String chipIp) {
        this.chipIp = chipIp;
    }
}
