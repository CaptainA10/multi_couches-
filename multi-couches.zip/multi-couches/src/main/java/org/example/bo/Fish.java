package org.example.bo;

import jakarta.persistence.Entity;

import java.util.Date;

@Entity
public class Fish extends Animal {
    private FishLiEnv livingEnv;

    public FishLiEnv getLivingEnv() {
        return livingEnv;
    }
    public Fish() {}

    // Constructeur avec tous les paramètres utilisés dans ton main
    public Fish(Long id, Date birth, String couleur, PetStore petStore, FishLiEnv livingEnv) {
        super(id, birth, couleur, petStore); // Appelle le constructeur de Animal
        this.livingEnv = livingEnv;
    }
    public void setLivingEnv(FishLiEnv livingEnv) {
        this.livingEnv = livingEnv;
    }
}
