package org.example.bo;

public enum ProdType {
    FOOD, ACCESSORY, CLEANING
}
