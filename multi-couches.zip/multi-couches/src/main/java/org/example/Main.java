package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.example.bo.*;
import java.util.Date;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        // Création de l'EntityManagerFactory
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("petstorePU");
        EntityManager em = emf.createEntityManager();

        try {
            // Début de la transaction
            em.getTransaction().begin();

            // Création des adresses
            Address address1 = new Address(1L, "12", "Rue des Lilas", "75000", "Paris");
            Address address2 = new Address(2L, "34", "Avenue Victor Hugo", "69000", "Lyon");
            Address address3 = new Address(3L, "56", "Boulevard Haussmann", "33000", "Bordeaux");

            em.persist(address1);
            em.persist(address2);
            em.persist(address3);

            // Création des animaleries
            PetStore store1 = new PetStore(1L, "Animal World", "Claire");
            PetStore store2 = new PetStore(2L, "Zoo Paradise", "Julien");
            PetStore store3 = new PetStore(3L, "Pet Family", "Sophie");

            em.persist(store1);
            em.persist(store2);
            em.persist(store3);

            // Création des produits
            Product p1 = new Product(1L, "P001", "Croquettes chien", ProdType.FOOD, 15.99);
            Product p2 = new Product(2L, "P002", "Collier rouge", ProdType.ACCESSORY, 9.49);
            Product p3 = new Product(3L, "P003", "Shampooing hypoallergénique", ProdType.CLEANING, 12.0);

            p1.setPetStores(Set.of(store1, store2));
            p2.setPetStores(Set.of(store1));
            p3.setPetStores(Set.of(store3));

            em.persist(p1);
            em.persist(p2);
            em.persist(p3);

            // Création des animaux
            Cat cat1 = new Cat(1L, new Date(), "Noir", store1, "CHIP123");
            Cat cat2 = new Cat(3L, new Date(), "Blanc", store2, "CHIP456");

            em.persist(cat1);
            em.persist(cat2);

            // Validation de la transaction
            em.getTransaction().commit();

            System.out.println("Données insérées avec succès !");
        } catch (Exception e) {
            // En cas d'erreur, annulation de la transaction
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // Fermeture des ressources
            em.close();
            emf.close();
        }
    }
}